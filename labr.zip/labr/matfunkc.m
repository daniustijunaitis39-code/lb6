function y = matfunkc(x)

y= zeros(size(x));
for i= 1:length(x)
    if x(i)<0;
        y(i)= -sin(x(i));
    else
        y(i)= sin(x(i));
    end
end
end

%[appendix]{"version":"1.0"}
%---
